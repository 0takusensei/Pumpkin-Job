FT SCRIPT'S

Make sure to check our other amazing resources that you'll definitely like
⭐[ Consumable Creator ](https://ftscripts.tebex.io/package/6489059)
⭐[ Car Dealer Creator ](https://ftscripts.tebex.io/package/6453344)
⭐[ Shops Creator ](https://ftscripts.tebex.io/package/6167797)
⭐[ Drug System ](https://ftscripts.tebex.io/package/6394112)
⭐[ White Widow Business ](https://ftscripts.tebex.io/package/6310613)
⭐[ Black Market Creator ](https://ftscripts.tebex.io/package/6280868)
⭐[ UWU Cafe Business ](https://ftscripts.tebex.io/package/6310604)

If you need support or any help, contact us on our discord!
Discord:https://discord.gg/whc8wcpzt9

1. All installation stuff can be found in folder INSTALL-FIRST